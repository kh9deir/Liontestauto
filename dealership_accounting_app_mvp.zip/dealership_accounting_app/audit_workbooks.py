
from pathlib import Path
import openpyxl, pandas as pd, json, sys
from datetime import datetime
files = sys.argv[1:] or list(Path(".").glob("*.xlsx"))
summary=[]
sheets=[]
for path in files:
    wb=openpyxl.load_workbook(path,data_only=False,read_only=True)
    wbv=openpyxl.load_workbook(path,data_only=True,read_only=True)
    for ws in wb.worksheets:
        wsv=wbv[ws.title]
        formulas=0; nonempty=0; blank_rows=0; first=[]
        for row in ws.iter_rows():
            vals=[cell.value for cell in row]
            if any(v is not None for v in vals):
                nonempty+=1
                if len(first)<8: first.append({"row":row[0].row,"values":[str(v)[:100] if v is not None else None for v in vals[:15]]})
            else: blank_rows+=1
            formulas += sum(1 for v in vals if isinstance(v,str) and v.startswith("="))
        sheets.append({"file":path.name,"sheet":ws.title,"rows":ws.max_row,"columns":ws.max_column,
                       "nonempty_rows":nonempty,"blank_rows":blank_rows,"formula_cells":formulas,
                       "sample_rows":json.dumps(first,ensure_ascii=False)})
    summary.append({"file":path.name,"sheets":len(wb.sheetnames),"sheet_names":" | ".join(wb.sheetnames)})
pd.DataFrame(summary).to_csv("excel_file_summary.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(sheets).to_csv("excel_sheet_audit.csv",index=False,encoding="utf-8-sig")
print("Wrote excel_file_summary.csv and excel_sheet_audit.csv")
