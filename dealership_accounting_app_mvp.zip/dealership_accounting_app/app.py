
import streamlit as st
import pandas as pd
import sqlite3, hashlib, os, json, re
from datetime import date, datetime
from pathlib import Path

DB = os.getenv("ACCOUNTING_DB", "dealership.db")
st.set_page_config(page_title="حسابات المعرض", page_icon="🚗", layout="wide")

def conn():
    c=sqlite3.connect(DB, check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS users(
      username TEXT PRIMARY KEY, password_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS accounts(
      code TEXT PRIMARY KEY, name TEXT NOT NULL, account_type TEXT NOT NULL, active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS journal_entries(
      id INTEGER PRIMARY KEY AUTOINCREMENT, entry_date TEXT NOT NULL, description TEXT NOT NULL,
      source TEXT DEFAULT 'manual', status TEXT DEFAULT 'draft', created_by TEXT NOT NULL,
      created_at TEXT NOT NULL, approved_by TEXT, approved_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS journal_lines(
      id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER NOT NULL, account_code TEXT NOT NULL,
      debit INTEGER DEFAULT 0, credit INTEGER DEFAULT 0, memo TEXT DEFAULT '',
      FOREIGN KEY(entry_id) REFERENCES journal_entries(id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS import_batches(
      id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, imported_at TEXT, imported_by TEXT,
      sheet_name TEXT, row_count INTEGER, warning_count INTEGER, status TEXT DEFAULT 'review_only')""")
    c.execute("""CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, action TEXT, detail TEXT, created_at TEXT)""")
    c.commit()
    return c

def pw(s): return hashlib.sha256(s.encode()).hexdigest()
def log(c,user,action,detail):
    c.execute("INSERT INTO audit_log(username,action,detail,created_at) VALUES(?,?,?,?)",
              (user,action,detail,datetime.now().isoformat(timespec="seconds")))
    c.commit()

c=conn()
if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
    c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("admin",pw("ChangeMe123!"),"admin"))
    c.commit()

if "user" not in st.session_state: st.session_state.user=None
if not st.session_state.user:
    st.title("🚗 حسابات المعرض")
    st.caption("نسخة أولية تجريبية | بيانات محلية على الجهاز")
    with st.form("login"):
        u=st.text_input("اسم المستخدم")
        p=st.text_input("كلمة المرور",type="password")
        ok=st.form_submit_button("تسجيل الدخول",use_container_width=True)
    if ok:
        row=c.execute("SELECT username,role FROM users WHERE username=? AND password_hash=? AND active=1",(u,pw(p))).fetchone()
        if row:
            st.session_state.user={"username":row["username"],"role":row["role"]}
            st.rerun()
        else: st.error("بيانات الدخول غير صحيحة")
    st.info("للدخول أول مرة: admin / ChangeMe123! ثم غيّر كلمة المرور قبل أي استخدام حقيقي.")
    st.stop()

user=st.session_state.user
role=user["role"]
st.sidebar.title("🚘 حسابات المعرض")
st.sidebar.write(f"المستخدم: **{user['username']}**")
st.sidebar.caption(f"الصلاحية: {role}")
if st.sidebar.button("تسجيل الخروج"):
    st.session_state.user=None; st.rerun()

pages=["لوحة التحكم","قيد يومية جديد","دفتر اليومية","استيراد Excel ومطابقة","دليل الحسابات","المستخدمون والصلاحيات","سجل المراجعة"]
if role=="viewer": pages=["لوحة التحكم","دفتر اليومية","استيراد Excel ومطابقة","دليل الحسابات"]
page=st.sidebar.radio("التنقل",pages)

def money(x): return f"{float(x or 0):,.2f} ج.م"
def load_entries():
    return pd.read_sql_query("""SELECT e.id,e.entry_date,e.description,e.source,e.status,e.created_by,
       COALESCE(SUM(l.debit),0) debit, COALESCE(SUM(l.credit),0) credit
       FROM journal_entries e LEFT JOIN journal_lines l ON l.entry_id=e.id
       GROUP BY e.id ORDER BY e.entry_date DESC,e.id DESC""",c)

if page=="لوحة التحكم":
    st.title("لوحة التحكم")
    entries=load_entries()
    total_d=float(entries.debit.sum()) if len(entries) else 0
    total_cr=float(entries.credit.sum()) if len(entries) else 0
    a,b,d,e=st.columns(4)
    a.metric("قيود مسجلة",len(entries))
    b.metric("إجمالي المدين",money(total_d))
    d.metric("إجمالي الدائن",money(total_cr))
    e.metric("فرق القيود",money(total_d-total_cr))
    st.subheader("آخر القيود")
    st.dataframe(entries.head(12),use_container_width=True,hide_index=True)
    st.warning("الأرصدة التاريخية لم تُرحّل إلى الدفاتر التشغيلية تلقائيًا. ابدأ من صفحة استيراد Excel للمراجعة فقط، ثم اعتمد خطة الترحيل بعد مطابقة الأرصدة.")

elif page=="قيد يومية جديد":
    st.title("قيد يومية جديد")
    if role not in ("admin","accountant"): st.error("ليس لديك صلاحية إنشاء القيود."); st.stop()
    accounts=pd.read_sql_query("SELECT code,name FROM accounts WHERE active=1 ORDER BY code",c)
    if accounts.empty:
        accounts=pd.DataFrame([{"code":"1000","name":"الخزينة"},{"code":"1100","name":"بنك CIB"},{"code":"1200","name":"مخزون سيارات"},{"code":"1300","name":"مدينون"},{"code":"2000","name":"دائنون"},{"code":"3000","name":"رأس المال"},{"code":"4000","name":"المبيعات"},{"code":"5000","name":"تكلفة المبيعات"},{"code":"6000","name":"مصروفات"}])
        st.info("دليل حسابات أولي مؤقت. أضف الحسابات الفعلية من صفحة دليل الحسابات.")
    opts={f"{r['code']} - {r['name']}":r['code'] for _,r in accounts.iterrows()}
    with st.form("entry"):
        dt=st.date_input("التاريخ",date.today())
        desc=st.text_input("بيان القيد")
        n=st.selectbox("عدد سطور القيد",[2,3,4,5,6,8])
        lines=[]
        for i in range(n):
            cols=st.columns([3,2,2,3])
            acc=cols[0].selectbox(f"الحساب {i+1}",list(opts),key=f"acc{i}")
            debit=cols[1].number_input(f"مدين {i+1}",min_value=0,step=1000,key=f"dr{i}")
            credit=cols[2].number_input(f"دائن {i+1}",min_value=0,step=1000,key=f"cr{i}")
            memo=cols[3].text_input(f"ملاحظة {i+1}",key=f"memo{i}")
            lines.append((opts[acc],int(debit),int(credit),memo))
        submit=st.form_submit_button("حفظ كمسودة")
    if submit:
        errors=[]
        if not desc.strip(): errors.append("اكتب بيان القيد.")
        if sum(x[1] for x in lines)!=sum(x[2] for x in lines): errors.append("القيد غير متوازن: إجمالي المدين لا يساوي إجمالي الدائن.")
        if not any(x[1] or x[2] for x in lines): errors.append("أدخل مبلغًا واحدًا على الأقل.")
        if any(x[1] and x[2] for x in lines): errors.append("لا يجوز أن يحتوي السطر نفسه على مدين ودائن معًا.")
        if errors:
            for er in errors: st.error(er)
        else:
            cur=c.execute("INSERT INTO journal_entries(entry_date,description,source,status,created_by,created_at) VALUES(?,?,?,?,?,?)",
                 (dt.isoformat(),desc,"manual","draft",user["username"],datetime.now().isoformat(timespec="seconds")))
            eid=cur.lastrowid
            c.executemany("INSERT INTO journal_lines(entry_id,account_code,debit,credit,memo) VALUES(?,?,?,?,?)",
                          [(eid,*x) for x in lines])
            log(c,user["username"],"create_entry",f"entry_id={eid}; status=draft")
            st.success(f"تم حفظ القيد رقم {eid} كمسودة. يحتاج إلى مراجعة واعتماد.")
            st.rerun()
    st.caption("كل المبالغ تحفظ بالجنيه المصري كأعداد صحيحة في هذه النسخة. عدّل وحدة العملة/الكسور عند الحاجة.")

elif page=="دفتر اليومية":
    st.title("دفتر اليومية")
    df=load_entries()
    if len(df):
        st.dataframe(df,use_container_width=True,hide_index=True)
        ids=df.id.tolist()
        selected=st.selectbox("اختر رقم القيد",ids)
        lines=pd.read_sql_query("SELECT l.account_code,a.name,l.debit,l.credit,l.memo FROM journal_lines l LEFT JOIN accounts a ON a.code=l.account_code WHERE l.entry_id=?",c,params=(selected,))
        st.dataframe(lines,use_container_width=True,hide_index=True)
        entry=c.execute("SELECT status FROM journal_entries WHERE id=?",(int(selected),)).fetchone()
        col1,col2=st.columns(2)
        if role in ("admin","manager") and entry and entry["status"]=="draft":
            if col1.button("اعتماد القيد"):
                c.execute("UPDATE journal_entries SET status='approved',approved_by=?,approved_at=? WHERE id=?",
                          (user["username"],datetime.now().isoformat(timespec="seconds"),int(selected)))
                log(c,user["username"],"approve_entry",f"entry_id={selected}")
                st.success("تم اعتماد القيد."); st.rerun()
        if role=="admin" and entry and entry["status"]=="draft":
            if col2.button("إلغاء المسودة"):
                c.execute("UPDATE journal_entries SET status='void' WHERE id=?",(int(selected),))
                log(c,user["username"],"void_entry",f"entry_id={selected}")
                st.rerun()
    else: st.info("لا توجد قيود بعد.")

elif page=="استيراد Excel ومطابقة":
    st.title("استيراد Excel ومطابقة البيانات التاريخية")
    st.write("الاستيراد في هذه المرحلة **للفحص فقط** ولا يرحّل قيودًا إلى دفتر اليومية. هذا مقصود لحماية أرصدة المعرض من التكرار أو اختلاف المعادلات.")
    uploaded=st.file_uploader("ارفع ملف Excel",type=["xlsx"])
    if uploaded:
        try:
            xls=pd.ExcelFile(uploaded)
            st.write("الأوراق المكتشفة:",", ".join(xls.sheet_names))
            sheet=st.selectbox("اختر ورقة للفحص",xls.sheet_names)
            df=pd.read_excel(uploaded,sheet_name=sheet,header=None)
            st.write(f"عدد الصفوف: {len(df)} | عدد الأعمدة: {len(df.columns)}")
            st.dataframe(df.head(40),use_container_width=True)
            warnings=[]
            empty_rows=int(df.isna().all(axis=1).sum())
            warnings.append(("صفوف فارغة",empty_rows))
            formula_cells=0
            try:
                import openpyxl, tempfile
                uploaded.seek(0)
                wb=openpyxl.load_workbook(uploaded,data_only=False,read_only=True)
                ws=wb[sheet]
                formula_cells=sum(1 for row in ws.iter_rows() for cell in row if isinstance(cell.value,str) and cell.value.startswith("="))
            except Exception: pass
            warnings.append(("خلايا بها معادلات",formula_cells))
            st.subheader("ملاحظات الفحص الأولي")
            for name,val in warnings: st.write(f"- {name}: {val}")
            st.warning("قيم المعادلات لا يمكن تأكيدها من معاينة واحدة فقط. يجب فتح نسخة بقيم محسوبة، ومقارنة رصيد أول وآخر المدة لكل ورقة قبل الترحيل.")
            if role in ("admin","accountant") and st.button("حفظ تقرير الفحص"):
                c.execute("INSERT INTO import_batches(filename,imported_at,imported_by,sheet_name,row_count,warning_count) VALUES(?,?,?,?,?,?)",
                    (uploaded.name,datetime.now().isoformat(timespec="seconds"),user["username"],sheet,len(df),empty_rows))
                log(c,user["username"],"excel_inspection",f"{uploaded.name}; sheet={sheet}; rows={len(df)}; formulas={formula_cells}")
                st.success("تم حفظ سجل الفحص، ولم يتم تعديل أي رصيد.")
        except Exception as ex: st.error(f"تعذر قراءة الملف: {ex}")
    st.subheader("اختبارات المطابقة المقترحة قبل الترحيل")
    checks=[
      "توحيد الفترة الزمنية والتأكد من عدم تكرار أشهر أو قيود بين الملفات.",
      "مقارنة رصيد أول المدة مع رصيد آخر الشهر السابق لكل خزينة وبنك.",
      "مقارنة إجمالي المدين والدائن للقيود المستخرجة، مع فصل الحركات التي لا تمثل قيدًا مزدوجًا.",
      "مقارنة مخزون كل سيارة: تكلفة الشراء + المصروفات المباشرة - تكلفة المبيعات.",
      "مطابقة أرصدة العملاء والموردين والحسابات الجارية للشركاء.",
      "إعادة حساب قائمة الأرباح والخسائر والمركز المالي ومراجعة الفرق النهائي.",
      "تسجيل أي اختلاف في تقرير استثناءات قبل اعتماد الترحيل."
    ]
    for x in checks: st.checkbox(x,key="check_"+str(checks.index(x)))

elif page=="دليل الحسابات":
    st.title("دليل الحسابات")
    if role in ("admin","accountant"):
        with st.form("newaccount"):
            code=st.text_input("كود الحساب")
            name=st.text_input("اسم الحساب")
            typ=st.selectbox("نوع الحساب",["أصول","التزامات","حقوق ملكية","إيرادات","مصروفات","حساب وسيط"])
            save=st.form_submit_button("إضافة حساب")
        if save:
            if not code.strip() or not name.strip(): st.error("الكود والاسم مطلوبان.")
            else:
                try:
                    c.execute("INSERT INTO accounts(code,name,account_type) VALUES(?,?,?)",(code.strip(),name.strip(),typ))
                    log(c,user["username"],"create_account",f"{code} {name}")
                    st.success("تمت إضافة الحساب."); st.rerun()
                except sqlite3.IntegrityError: st.error("كود الحساب موجود بالفعل.")
    df=pd.read_sql_query("SELECT code,name,account_type,active FROM accounts ORDER BY code",c)
    st.dataframe(df,use_container_width=True,hide_index=True)
    st.caption("يجب إعداد دليل الحسابات النهائي من مسميات ملفات المعرض قبل بدء الترحيل الفعلي.")

elif page=="المستخدمون والصلاحيات":
    st.title("المستخدمون والصلاحيات")
    if role!="admin": st.error("هذه الصفحة للمدير المسؤول فقط."); st.stop()
    with st.form("newuser"):
        username=st.text_input("اسم المستخدم الجديد")
        password=st.text_input("كلمة مرور مؤقتة",type="password")
        r=st.selectbox("الصلاحية",["accountant","manager","viewer","admin"])
        create=st.form_submit_button("إنشاء مستخدم")
    if create:
        if len(password)<10: st.error("استخدم كلمة مرور لا تقل عن 10 أحرف.")
        else:
            try:
                c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",(username,pw(password),r))
                log(c,user["username"],"create_user",f"{username}; role={r}")
                st.success("تم إنشاء المستخدم."); st.rerun()
            except sqlite3.IntegrityError: st.error("اسم المستخدم مستخدم بالفعل.")
    st.write({"admin":"إدارة كاملة","manager":"مراجعة واعتماد القيود","accountant":"إدخال القيود والحسابات","viewer":"عرض فقط"})
    st.dataframe(pd.read_sql_query("SELECT username,role,active FROM users ORDER BY username",c),use_container_width=True,hide_index=True)

elif page=="سجل المراجعة":
    st.title("سجل المراجعة")
    if role!="admin": st.error("هذه الصفحة للمدير المسؤول فقط."); st.stop()
    st.dataframe(pd.read_sql_query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500",c),use_container_width=True,hide_index=True)

st.sidebar.divider()
st.sidebar.caption("نسخة MVP: لا تعتمد التقارير المالية قبل استكمال ترحيل البيانات والتحقق منها.")
